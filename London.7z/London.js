/*var udaje = $.getJSON( "http://api.openweathermap.org/data/2.5/weather",
 {id:"724443",units:'metric',APPID:"8641355d0bdfa52a49f4e9a42560adf0"},
 vypis);

 var tmpl = "Teplota: {{main.temp}}, Tlak: {{main.pressure}}, Oblačnosť: {{clouds.all}}%";

 function vypis(udaje){
 console.log(udaje);
 }

 function spracuj(udaje){
 Mustache.render(tmpl, udaje);
 }*/

var $frm = $("#frmArt");

$frm.submit(function (event) {
    event.preventDefault();
    skontrolujAOdosli();
});

function skontrolujAOdosli() {
    var data = {};
    $frm.serializeArray().map(
        function (item) {
            var itemValueTrimmed = item.value.trim();
            if (itemValueTrimmed) {
                data[item.name] = itemValueTrimmed;
            }
        }
    );

    console.log("skontrolujAOdosli> Ăšdaje po uloĹľenĂ­ z formulĂˇra do objektu:");

    data.concent = "<div> " + data.content + "</div>";
    switch (data.times) {
        case "0":
            data.content += "<p> I have never been there </p>";
            break;
        case "1":
            data.content += "<p> I have been in London once </p>";
            break;
        case "2":
            data.content += "<p> I have been in London more than once </p>";
            break;
    }

    delete data.times;

    switch (data.sex) {
        case "m":
            data.content += "<p> I am a man </p>";
            break;
        case "f":
            data.content += "<p> I am a woman </p>";
            break;
        case "x":
            data.content += "<p> I don't know which sex I am </p>";
            break;
    }

    delete data.sex;


    if (data.place1) {
        data.content += "<p> I have visited London Eye</p>";
    }
    if (data.place2) {
        data.content += "<p> I have visited Big Ben </p>";
    }
    if (data.place3) {
        data.content += "<p> I have visited Buckingham Palace </p>";
    }

    delete data.place1;
    delete data.place2;
    delete data.place3;


    switch (data.favouritePlaces) {
        case "LE":
            data.content += "<p> I liked London Eye </p>";
            break;
        case "BB":
            data.content += "<p> I liked Big Ben </p>";
            break;
        case "BP":
            data.content += "<p> I liked Buckingham Palace </p>";
            break;
    }

    delete data.favouritePlaces;
    


    console.log("prepareAndSendArticle> PovinnĂ© Ăşdaje ĂşspeĹˇne skontrolovanĂ©:");
    console.log(JSON.stringify(data));

    if (window.confirm("SkutoÄŤne si ĹľelĂˇte ÄŤlĂˇnok odoslaĹĄ?")) {
        $.ajax({
            type: "POST",
            url: "http://wt.kpi.fei.tuke.sk/api/article",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            data: JSON.stringify(data),
            success: function (response) {
                if (response.id) {
                    console.log(response.id);
                    window.alert("ÄŚlĂˇnok ĂşspeĹˇne uloĹľenĂ˝ s id=" + response.id + ".");
                    window.open('http://hron.fei.tuke.sk/~korecko/WebTechAkademia/wtKpiBlogBrowser/article.html?id=' + response.id, '_blank');
                    $frm.trigger('reset');
                }
            },
            error: function (jxhr) {
                window.alert("Spracovanie neĂşspeĹˇnĂ©. Ăšdaje neboli zapĂ­sanĂ©. KĂłd chyby:" + status + "\n" + jxhr.statusText + "\n" + jxhr.responseText);
            }
        });
    }
}








